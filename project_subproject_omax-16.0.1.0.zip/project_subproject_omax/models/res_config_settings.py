# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'
    
    group_allow_subprojects = fields.Boolean("Sub-projects",implied_group='project_subproject_omax.group_allow_subprojects')
    
    @api.model
    def get_values(self):
        """get values from the fields"""
        res = super(ResConfigSettings, self).get_values()
        res.update(
            group_allow_subprojects = self.env['ir.config_parameter'].sudo().get_param('group_allow_subprojects')
            )
        return res
    
    def set_values(self):
        """Set values in the fields"""
        super(ResConfigSettings, self).set_values()
        self.env['ir.config_parameter'].sudo().set_param('group_allow_subprojects', self.group_allow_subprojects)
    
    
